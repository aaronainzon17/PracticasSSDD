docker build . -t localhost:5000/test:latest
docker push localhost:5000/test:latest