kubectl delete -f raft_tests_stateful.yaml
kubectl create -f raft_tests_stateful.yaml