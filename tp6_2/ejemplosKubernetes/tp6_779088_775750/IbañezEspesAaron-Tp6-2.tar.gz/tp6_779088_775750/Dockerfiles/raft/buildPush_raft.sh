docker build . -t localhost:5000/raft:latest
docker push localhost:5000/raft:latest